#include <iostream>
#include <ctime>
#include <string>
using namespace std;

class Time{
    
    private:
    
    int hour;
    int minute;
    int second;
    
    public:
    
    Time(int hr,int min,int sec)
    :hour(hr),minute(min),second(sec){}
    Time(){
        Time(0,0,0);
    }
    
    void setTime(){
        time_t now = time(0);
        tm *current_time = localtime(&now);
        this->hour = 5 + current_time->tm_hour;
        this->minute = 30 + current_time->tm_min;
        this->second = current_time->tm_sec;
    }
    
    string getTime(){
        string current_time = "Current Time is:";
        current_time += to_string(this->hour);
        current_time += ":";
        current_time += to_string(this->minute);
        current_time += ":";
        current_time += to_string(this->second);
        return current_time;
    }
    
    Time sleepTime(Time instance1,Time instance2){
        int diff_hour = (instance1.hour - instance2.hour);
        int diff_minute = (instance1.minute - instance2.minute);
        int diff_second = (instance1.second - instance2.second);
        Time diff_time(diff_hour,diff_minute,diff_second);
        return  diff_time;
    }
};

class Date{
    
    public:
    
    int day;
    int month;
    int year;

    
    Date(int d,int mnth,int yr)
    :day(d),month(mnth),year(yr){}
    Date(){
        Date(0,0,0);
    }
    Date setDate(){
        time_t now = time(0);
        tm *current_time = localtime(&now);
        this->year = 1900 + current_time->tm_year;
        this->month = 1 + current_time->tm_mon;
        this->day = current_time->tm_mday;
        return *this;
    }
    
    Date getDate(){
        return *this;
    }
    
    Date DoB(int day,int month,int year){
        Date date(day,month,year);
        return date;
    }
    
    void findAge(Date date){
        this->setDate();
        int diff_day = (this->day - date.day);
        int diff_month = (this->month - date.month);
        int diff_year = (this->year - date.year);
        Date Age(diff_day,diff_month,diff_year);
        cout<<"Age is:"<<Age.day<<" Days "<<Age.month<<" ,Months and "<<Age.year<<" Years\n";
    }
    
};


int main(){
    
    Time *time = new Time();
    time->setTime();
    cout<<"Current time:"<<time->getTime()<<"\n";
    Time instance1(5,4,3);
    Time instance2(3,2,1);
    Time diff_time = time->sleepTime(instance1,instance2);
    cout<<"Diff in Time:"<<diff_time.getTime()<<"\n";
    
    
    Date *date = new Date();
    date->setDate();
    Date date_value = date->getDate();
    cout<<"Current Date is:"<<date_value.day<<" Days "<<date_value.month<<" ,Months and "<<date_value.year<<" Years\n";
    
    Date dob = date->DoB(5,7,2001);
    cout<<"DOB is:"<<dob.day<<" Days "<<dob.month<<" ,Months and "<<dob.year<<" Years\n";
    
    date->findAge(dob);
    
    
    return 0;
}