/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

class Measure {
    
    public:
        
        int height, length, width;
        
        void setInput(int h, int l, int w) {
            
            height = h;
            length = l;
            width = w;
        }
        
        int area() {
            
            return width*length;
        }
        
        int volume() {
            
            return height*width*length;
        }
    
};

int main()
{
    Measure obj1, obj2;
    
    obj1.setInput(2,3,4);
    obj2.setInput(5,6,7);
    
    cout << "Area: " << obj1.area() << "\n" << "Volume: " << obj2.volume();

    return 0;
}
