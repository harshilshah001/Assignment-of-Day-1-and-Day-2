#include <iostream>

using namespace std;
class Calculator {
    public:
        int input1;
        int input2;
        void setInput (int a, int b) {
        input1 = a;
        input2 = b;
        }
        int add() {
        return input1+input2;
        }

        int sub() {
        return input1-input2;
        }

        int multi() {
        return input1*input2;
        }

        int divide() {
        return input1/input2;
        }
};
int main () {
    Calculator obj1;
    int inp;
    obj1.setInput(10,2);
    cout << "The inputs: " << obj1.input1 << " " << obj1.input2 << endl;

    cout << "Enter 1 for Addition\nEnter 2 for Substraction\nEnter 3 for Multiplication\nEnter 4 for Division\n";
    cin >> inp;

    switch(inp) {
        case 1: {
            cout << "The addition is: " << obj1.add();
            }
        break;

        case 2: {
            cout << "The substraction is: " << obj1.sub();
            }
        break;

        case 3: {
            cout << "The multiplication is: " << obj1.multi();
            }
        break;

        case 4: {
            cout << "The division is: " << obj1.divide();
            }
        break;

        default: cout << "Enter valid input";
        break;
    }

    return 0;
}